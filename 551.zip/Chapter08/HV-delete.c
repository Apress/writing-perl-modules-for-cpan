hv_clear(hv); // %hv = ();
hv_delete(hv, "foo", strlen("foo"), 0); // delete $hv{foo}
