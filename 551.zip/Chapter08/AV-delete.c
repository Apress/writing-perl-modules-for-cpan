av_clear(av); // @av = ();
av_delete(av, 9, 0); // delete the tenth element (the last arg is ignored)
