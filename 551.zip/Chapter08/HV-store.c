SV *sv_value = newSViv(100);
hv_store(hv, "fuel_remaining", strlen("fuel_remaining"), sv_value, 0);
