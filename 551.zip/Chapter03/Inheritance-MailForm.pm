package CGI::MailForm;
use CGI;
@ISA = qw(CGI);
1;
