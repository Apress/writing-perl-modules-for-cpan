package BOA::Probe;
use Class::MethodMaker
   new     => 'new',
   get_set => [ qw(id model contents heading status) ];

1;
